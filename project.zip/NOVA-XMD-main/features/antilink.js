import { getGroupSettings, addWarn, resetWarn, getWarnLimit, getTrustedLinks } from '../database/config.js';
import { resolveTargetJid } from '../lib/lidResolver.js';

const DEV_NUMBER = '255767862457';

const _num = (jid) => (jid || '').split('@')[0].split(':')[0].replace(/\D/g, '');

const _pNum = (p) => {
    const phone = p.phoneNumber || p.phone_number || '';
    if (phone) return _num(phone);
    const base = p.id || p.jid || '';
    if (base && !base.endsWith('@lid')) return _num(base);
    return _num(p.lid || base);
};

const isDevJid = (jid) => _num(jid) === DEV_NUMBER;

function extractDomains(text) {
    const domains = [];
    const urlRegex = /(https?:\/\/[^\s]+|www\.[^\s]+|[a-z0-9.-]+\.[a-z]{2,6}(\/[^\s]*)?)/gi;
    const matches = text.match(urlRegex) || [];
    for (const m of matches) {
        try {
            const u = m.startsWith('http') ? new URL(m) : new URL('https://' + m);
            domains.push(u.hostname.replace(/^www\./, '').toLowerCase());
        } catch {
            domains.push(m.toLowerCase().replace(/^www\./, '').split('/')[0]);
        }
    }
    return domains;
}

export default async (client, m) => {
    try {
        if (!m || !m.chat || !m.chat.endsWith('@g.us')) return;
        if (m.key?.fromMe) return;
        if (isDevJid(m.sender)) return;

        const groupSettings = await getGroupSettings(m.chat);
        const antilinkMode = (groupSettings.antilink || 'off').toLowerCase();
        if (antilinkMode === 'off') return;

        const msg = m.message || {};
        const innerMsg = msg.extendedTextMessage || msg.imageMessage || msg.videoMessage ||
            msg.documentMessage || msg.audioMessage || msg.stickerMessage || null;
        const contextInfo = (typeof innerMsg === 'object' && innerMsg?.contextInfo) || msg.contextInfo || null;
        const isForwarded = contextInfo?.isForwarded === true;
        const forwardingScore = contextInfo?.forwardingScore || 0;
        const originJid = contextInfo?.remoteJid || '';
        const isChannelForward = isForwarded && (forwardingScore >= 1 || originJid.endsWith('@newsletter'));

        const text = (m.text || msg.conversation || msg.extendedTextMessage?.text ||
            msg.imageMessage?.caption || msg.videoMessage?.caption ||
            msg.documentMessage?.caption || '').toLowerCase();
        const urlRegex = /(https?:\/\/[^\s]+|www\.[^\s]+|[a-z0-9.-]+\.[a-z]{2,6}(\/[^\s]*)?)/gi;
        const hasPreview = msg.extendedTextMessage?.matchedText || msg.extendedTextMessage?.canonicalUrl;
        const hasLink = urlRegex.test(text) || !!hasPreview;

        if (!isChannelForward && !hasLink) return;

        if (hasLink && !isChannelForward) {
            try {
                const ownCode = await client.groupInviteCode(m.chat);
                const ownLink = `https://chat.whatsapp.com/${ownCode}`;
                const rawText = m.text || msg.conversation || msg.extendedTextMessage?.text || '';
                if (rawText.includes(ownLink) || rawText.includes(ownCode)) return;
            } catch {}
        }

        if (hasLink && !isChannelForward) {
            try {
                const trustedDomains = await getTrustedLinks(m.chat);
                if (trustedDomains && trustedDomains.length > 0) {
                    const msgDomains = extractDomains(text);
                    const previewDomain = hasPreview
                        ? (() => {
                            try { return new URL(hasPreview).hostname.replace(/^www\./, '').toLowerCase(); } catch { return ''; }
                        })()
                        : '';
                    const allDomains = msgDomains.concat(previewDomain ? [previewDomain] : []);
                    if (allDomains.length > 0 && allDomains.every(d => trustedDomains.some(t => d === t || d.endsWith('.' + t)))) {
                        return;
                    }
                }
            } catch {}
        }

        const groupMetadata = await client.groupMetadata(m.chat);
        const sender = resolveTargetJid(m.sender, groupMetadata.participants);

        if (!sender) return;

        const senderNum = _num(sender);
        const botRaw = client.decodeJid ? client.decodeJid(client.user.id) : (client.user?.id || '');
        const botNum = _num(botRaw);

        const isAdmin = groupMetadata.participants.some(p => {
            return _pNum(p) === senderNum && (p.admin === 'admin' || p.admin === 'superadmin');
        });
        const isBotAdmin = groupMetadata.participants.some(p => {
            return _pNum(p) === botNum && (p.admin === 'admin' || p.admin === 'superadmin');
        });

        const username = senderNum || sender.split('@')[0];
        const reason = isChannelForward ? '📡 channel forward detected' : '🔗 link detected';

        if (isAdmin) return;

        if (!isBotAdmin) {
            await client.sendMessage(m.chat, {
                text: `link detected\n@${username} make me admin to enforce this.`,
                mentions: [sender] });
            return;
        }

        try {
            await client.sendMessage(m.chat, {
                delete: {
                    remoteJid: m.chat,
                    fromMe: false,
                    id: m.key.id,
                    participant: m.key.participant || m.sender
                }
            });
        } catch (e) {
        }

        if (antilinkMode === 'delete') {
            await client.sendMessage(m.chat, {
                text: `${reason}, message deleted\n@${username} avoid sending links.`,
                mentions: [sender] });
            return;
        }

        if (antilinkMode === 'kick') {
            try {
                await client.groupParticipantsUpdate(m.chat, [sender], 'remove');
                await client.sendMessage(m.chat, {
                    text: `${reason}, message deleted\n@${username} kicked for sending a link.`,
                    mentions: [sender]
                });
            } catch (e) {
            }
            return;
        }

        const MAX_WARNS = await getWarnLimit(m.chat);
        const newCount = await addWarn(m.chat, username);
        const remaining = MAX_WARNS - newCount;

        if (newCount >= MAX_WARNS) {
            await resetWarn(m.chat, username);
            try { await client.groupParticipantsUpdate(m.chat, [sender], 'remove'); } catch {}
            await client.sendMessage(m.chat, {
                text: `${reason}, message deleted\n@${username} kicked, warn limit ${newCount}/${MAX_WARNS} reached.`,
                mentions: [sender]
            });
            return;
        }

        await client.sendMessage(m.chat, {
            text: `${reason}, message deleted\n@${username} avoid sending links. Warn ${newCount}/${MAX_WARNS}.`,
            mentions: [sender]
        });
    } catch (err) {
        console.error('[ANTILINK] Error:', err.message);
    }
};
