import { uploadToUrl } from '../../lib/toUrl.js';
  import { makeCanvas } from '../../lib/toxicApi.js';
    import { getSettings } from '../../database/config.js';
import { sendInteractive } from '../../lib/sendInteractive.js';

  const CANVAS_TYPES = [
      'spotify', 'youtube', 'google', 'tiktok', 'duckduckgo', 'brave', 'applemusic',
      'soundcloud', 'pinterest', 'playstore', 'happymod', 'apkpure', 'unsplash',
      'wallpaper', 'wattpad', 'weather', 'sticker', 'lyrics', 'shazam', 'web', 'image',
  ];

  export default {
      name: 'canvas',
      aliases: ['canvascard', 'spotifycard', 'youtubecard', 'tiktokcard'],
      description: 'Generate themed canvas cards from an image',
      category: 'Editing',
      run: async (context) => {
          const { client, m } = context;
        await client.sendMessage(m.chat, { react: { text: '⌛', key: m.reactKey } });
          const settings = await getSettings();
          const prefix = settings.prefix || '.';

          const quoted = m.quoted ? m.quoted : null;
          const mime = quoted?.mimetype || '';
          const args = (m.text || '').replace(/^S+s*/, '').trim();

          const typesList = CANVAS_TYPES.map(t => `│ • ${t}`).join('\n');
          const usageMsg = `📌 *CANVAS CARD*\n━━━━━━━━━━━━━━━━\nReply to an image to use this.\n*Usage:*\n${prefix}canvas Title | type | text | watermark\n*Example:*\n${prefix}canvas Blinding Lights | spotify | The Weeknd | NOVA-XMD\n${prefix}canvas My Video | youtube | Subscribe Now | BOT\n*Available Types (${CANVAS_TYPES.length}):*\n━━━━━━━━━━━━━━━━\n© bmb tech`;

          if (!quoted || !/image/.test(mime)) {
              await client.sendMessage(m.chat, { react: { text: '❌', key: m.reactKey } }).catch(() => {});
              return client.sendMessage(m.chat, { text: usageMsg });
          }

          const parts = args.split('|').map(s => s.trim());
          const title = parts[0] || 'Unknown Title';
          const rawType = (parts[1] || 'spotify').toLowerCase();
          const type = CANVAS_TYPES.includes(rawType) ? rawType : 'spotify';
          const text = parts[2] || '';
          const watermark = parts[3] || 'NOVA-XMD';

          if (parts[1] && !CANVAS_TYPES.includes(rawType)) {
              return sendInteractive(client, m, `❌ *ERROR*\n━━━━━━━━━━━━━━━━\nInvalid type: *${parts[1]}*\nValid types:\n━━━━━━━━━━━━━━━━\n© bmb tech`);
          }

          await client.sendMessage(m.chat, { react: { text: '⌛', key: m.reactKey } });

          try {
              const media = await quoted.download();
              const imgUrl = await uploadToUrl(media);
              const cardBuf = await makeCanvas(imgUrl, title, type, text, watermark);

              await client.sendMessage(m.chat, { react: { text: '✅', key: m.reactKey } });
              await client.sendMessage(m.chat, {
                  image: cardBuf,
                  caption: `📌 *CANVAS CARD*\n━━━━━━━━━━━━━━━━\n*Type:* ${type}\n*Title:* ${title}\n━━━━━━━━━━━━━━━━\n© bmb tech`
              });
          } catch {
              await client.sendMessage(m.chat, { react: { text: '❌', key: m.reactKey } });
              await sendInteractive(client, m, `❌ *ERROR*\n━━━━━━━━━━━━━━━━\nCanvas generation failed. Try again later.\n━━━━━━━━━━━━━━━━\n© bmb tech`);
          }
      }
  };
  