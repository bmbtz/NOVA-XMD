import { randomUUID } from 'crypto';
import { sendInteractive } from '../../lib/sendInteractive.js';

export default {
    name: 'tesq',
    alias: ['fakeai', 'metaai', 'aicode'],
    description: 'Send a fake Meta AI styled message with code block',
    run: async (context) => {
        const { client, m, text, sendJson } = context;
        await client.sendMessage(m.chat, { react: { text: '⌛', key: m.reactKey } });
        const msgText = text || 'HACKED BY NOVA-XMD 💀';
        const intro = `*NOVA-XMD AI*\nHere's what I found:\n\n`;
        const unifiedData = Buffer.from(JSON.stringify({
            response_id: randomUUID(),
            sections: [
                {
                    view_model: {
                        primitive: {
                            text: intro,
                            __typename: 'GenAIMarkdownTextUXPrimitive'
                        },
                        __typename: 'GenAISingleLayoutViewModel'
                    }
                },
                {
                    view_model: {
                        primitive: {
                            language: 'javascript',
                            code_blocks: [
                                { content: 'console.log(', type: 'DEFAULT' },
                                { content: `"${msgText}"`, type: 'STR' },
                                { content: ');', type: 'DEFAULT' }
                            ],
                            __typename: 'GenAICodeUXPrimitive'
                        },
                        __typename: 'GenAISingleLayoutViewModel'
                    }
                }
            ]
        })).toString('base64');

        const msgContent = {
            messageContextInfo: {
                botMetadata: {
                    modelMetadata: {},
                    progressIndicatorMetadata: {},
                    imagineMetadata: {},
                    memoryMetadata: {},
                    richResponseSourcesMetadata: {},
                    botAgeCollectionMetadata: {},
                    unifiedResponseMutation: {}
                }
            },
            botForwardedMessage: {
                message: {
                    richResponseMessage: {
                        messageType: 'AI_RICH_RESPONSE_TYPE_STANDARD',
                        submessages: [
                            {
                                messageType: 'AI_RICH_RESPONSE_TEXT',
                                messageText: intro
                            },
                            {
                                messageType: 'AI_RICH_RESPONSE_CODE',
                                codeMetadata: {
                                    codeLanguage: 'javascript',
                                    codeBlocks: [
                                        { highlightType: 'AI_RICH_RESPONSE_CODE_HIGHLIGHT_DEFAULT', codeContent: 'console.log(' },
                                        { highlightType: 'AI_RICH_RESPONSE_CODE_HIGHLIGHT_STRING', codeContent: `"${msgText}"` },
                                        { highlightType: 'AI_RICH_RESPONSE_CODE_HIGHLIGHT_DEFAULT', codeContent: ');' }
                                    ]
                                }
                            }
                        ],
                        unifiedResponse: { data: unifiedData },
                        contextInfo: {
                            forwardingScore: 743,
                            isForwarded: true,
                            forwardedAiBotMessageInfo: { botJid: '867051314767696@bot' },
                            pairedMediaType: 'NOT_PAIRED_MEDIA',
                            forwardOrigin: 'META_AI',
                            botMessageSharingInfo: {
                                botEntryPointOrigin: 'FAVICON',
                                forwardScore: 743
                            }
                        }
                    }
                }
            }
        };

        try {
            await sendJson(client, m.chat, msgContent);
        } catch (err) {
    await client.sendMessage(m.chat, { react: { text: '❌', key: m.reactKey } }).catch(() => {});
            console.error('tesq error:', err?.message);
            await client.sendMessage(m.chat, { react: { text: '⌛', key: m.reactKey } });
            await sendInteractive(client, m, `🤖 *BMB AI*\n━━━━━━━━━━━━━━━━\n${msgText}\n━━━━━━━━━━━━━━━━\n© bmb tech`);
        }
    }
};
