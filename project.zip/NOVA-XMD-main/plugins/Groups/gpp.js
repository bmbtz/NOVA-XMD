import { getSettings } from '../../database/config.js';
import ownerMiddleware from '../../utils/botUtil/Ownermiddleware.js';
import { sendInteractive } from '../../lib/sendInteractive.js';

const formatStylishReply = (message) => {
    return `📌 *GPP*\n━━━━━━━━━━━━━━━━\n${message}\n━━━━━━━━━━━━━━━━\n© bmb tech`;
};

export default async (context) => {
    await ownerMiddleware(context, async () => {
        const { client, m, text, isBotAdmin, IsGroup } = context;
        const quoted = context.quoted || m.quoted;
        await client.sendMessage(m.chat, { react: { text: '⌛', key: m.reactKey } });
        
        if (!IsGroup) {
            await client.sendMessage(m.chat, { react: { text: '❌', key: m.reactKey } }).catch(() => {});
            return sendInteractive(client, m, formatStylishReply("Group only command idiot"));
        }
        
        if (!isBotAdmin) {
            await client.sendMessage(m.chat, { react: { text: '❌', key: m.reactKey } }).catch(() => {});
            return sendInteractive(client, m, formatStylishReply("I need to be *admin* to change group picture. Please make me admin first."));
        }
        
        const isAdmin = m.isAdmin;
        if (!isAdmin) {
            await client.sendMessage(m.chat, { react: { text: '❌', key: m.reactKey } }).catch(() => {});
            return sendInteractive(client, m, formatStylishReply("You're not admin!"));
        }
        
        let imageBuffer;
        
        if (quoted && (quoted.mimetype?.startsWith('image/') || quoted.mtype === 'imageMessage' || quoted.msg?.mimetype?.startsWith('image/') || quoted.message?.imageMessage)) {
            try {
                imageBuffer = await quoted.download();
            } catch {
                await client.sendMessage(m.chat, { react: { text: '❌', key: m.reactKey } }).catch(() => {});
                return sendInteractive(client, m, formatStylishReply("Can't download image"));
            }
        }
        else if (m.message?.imageMessage || m.mtype === 'imageMessage') {
            try {
                imageBuffer = await m.download();
            } catch {
                await client.sendMessage(m.chat, { react: { text: '❌', key: m.reactKey } }).catch(() => {});
                return sendInteractive(client, m, formatStylishReply("Can't download image"));
            }
        }
        else {
            await client.sendMessage(m.chat, { react: { text: '❌', key: m.reactKey } }).catch(() => {});
            return sendInteractive(client, m, formatStylishReply("Send or reply with image"));
        }
        
        if (!imageBuffer) {
            await client.sendMessage(m.chat, { react: { text: '❌', key: m.reactKey } }).catch(() => {});
            return sendInteractive(client, m, formatStylishReply("Invalid image"));
        }
        
        try {
            await client.updateProfilePicture(m.chat, imageBuffer);
            await client.sendMessage(m.chat, { react: { text: '✅', key: m.reactKey } });
            return sendInteractive(client, m, formatStylishReply("Group picture updated"));
        } catch (error) {
            await client.sendMessage(m.chat, { react: { text: '❌', key: m.reactKey } });
            return sendInteractive(client, m, formatStylishReply("Failed to update picture"));
        }
    });
};
