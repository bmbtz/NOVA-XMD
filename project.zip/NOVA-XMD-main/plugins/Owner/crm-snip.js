import ownerMiddleware from '../../utils/botUtil/Ownermiddleware.js';
import { sendInteractive } from '../../lib/sendInteractive.js';

const STRUCT_KEYS = ['ephemeralMessage', 'viewOnceMessage', 'viewOnceMessageV2', 'viewOnceMessageV2Extension', 'documentWithCaptionMessage', 'editedMessage', 'deviceSentMessage', 'futureProofMessage', 'commentMessage', 'botInvokeMessage', 'botForwardedMessage', 'associatedChildMessage'];

const unwrap = (msg) => {
    let cur = msg;
    let guard = 0;
    while (cur && guard < 25) {
        const k = STRUCT_KEYS.find((key) => cur[key]);
        if (!k) break;
        cur = cur[k].message || cur[k];
        guard++;
    }
    return cur;
};

const encode = (val) => {
    if (val === null || val === undefined) return val;
    if (Buffer.isBuffer(val)) return { __b64__: val.toString('base64') };
    if (val instanceof Uint8Array) return { __b64__: Buffer.from(val).toString('base64') };
    if (Array.isArray(val)) return val.map(encode);
    if (typeof val === 'object') {
        if (val.type === 'Buffer' && Array.isArray(val.data)) return { __b64__: Buffer.from(val.data).toString('base64') };
        if (val.constructor?.name === 'Long') return val.toNumber?.() ?? val.low ?? 0;
        const out = {};
        for (const [k, v] of Object.entries(val)) out[k] = encode(v);
        return out;
    }
    return val;
};

const deepGetMessage = (m, store) => {
    const sources = [
        () => m.quoted?.fakeObj?.message,
        () => m.msg?.contextInfo?.quotedMessage,
        () => m.quoted?.message,
        () => {
            if (!store?.messages?.[m.chat]) return null;
            const msgs = store.messages[m.chat];
            return msgs.get?.({ id: m.quoted?.id })?.message || null;
        },
        () => m.quoted?.fakeObj,
    ];
    for (const fn of sources) {
        try {
            const r = fn();
            if (r && typeof r === 'object' && Object.keys(r).length > 0) return r;
        } catch {}
    }
    return null;
};

const sendRichCode = async (client, m, introText, code, language = 'javascript') => {
    const responseId = Math.random().toString(36).substring(2);
    const encodedData = Buffer.from(JSON.stringify({
        response_id: responseId,
        sections: [
            { view_model: { primitive: { text: introText, __typename: 'GenAIMarkdownTextUXPrimitive' }, __typename: 'GenAISingleLayoutViewModel' } },
            { view_model: { primitive: { language, code_blocks: [{ content: code, type: 'DEFAULT' }], __typename: 'GenAICodeUXPrimitive' }, __typename: 'GenAISingleLayoutViewModel' } }
        ]
    })).toString('base64');

    const content = {
        messageContextInfo: {
            threadId: [],
            deviceListMetadata: { senderKeyIndexes: [], recipientKeyIndexes: [] },
            deviceListMetadataVersion: 2,
            botMetadata: { pluginMetadata: {}, richResponseSourcesMetadata: { sources: [] } }
        },
        botForwardedMessage: {
            message: {
                richResponseMessage: {
                    submessages: [
                        { messageType: 2, messageText: introText },
                        { messageType: 3, codeMetadata: { codeLanguage: language, codeBlocks: [{ highlightType: 0, codeContent: code }] } }
                    ],
                    messageType: 1,
                    unifiedResponse: { data: encodedData },
                    contextInfo: { mentionedJid: [], groupMentions: [], statusAttributions: [], forwardingScore: 743, isForwarded: true, forwardedAiBotMessageInfo: { botJid: '867051314767696@bot' }, forwardOrigin: 4 }
                }
            }
        }
    };
    await client.relayMessage(m.chat, content, {});
};

export default async (context) => {
    await ownerMiddleware(context, async () => {
        const { client, m, store } = context;
        await client.sendMessage(m.chat, { react: { text: '⌛', key: m.reactKey } });

        const fmt = (msg) => `📌 *CRM-SNIP*\n━━━━━━━━━━━━━━━━\n${msg}\n━━━━━━━━━━━━━━━━\n© bmb tech`;

        if (!m.quoted) {
            await client.sendMessage(m.chat, { react: { text: '❌', key: m.reactKey } }).catch(() => {});
            return sendInteractive(client, m, fmt('Reply to a msg😠'));
        }

        try {
            const sources = [
                () => m.quoted?.fakeObj?.message,
                () => m.msg?.contextInfo?.quotedMessage,
                () => m.quoted?.message,
                () => m.quoted?.fakeObj,
            ];
            let raw = null;
            for (const fn of sources) {
                try { const r = fn(); if (r && typeof r === 'object' && Object.keys(r).length > 0) { raw = r; break; } } catch {}
            }

            if (!raw) {
                await client.sendMessage(m.chat, { react: { text: '❌', key: m.reactKey } }).catch(() => {});
                return sendInteractive(client, m, fmt('Could not read that message. Reply directly to it and try again.'));
            }

            const core = unwrap(raw) || raw;
            const contextInfo = m.msg?.contextInfo || m.quoted?.contextInfo || null;
            const messageContextInfo = raw?.messageContextInfo || m.quoted?.fakeObj?.messageContextInfo || null;

            const capture = {
                message: encode(core),
                ...(contextInfo ? { capturedContextInfo: encode(contextInfo) } : {}),
                ...(messageContextInfo ? { messageContextInfo: encode(messageContextInfo) } : {}),
            };

            const payload = JSON.stringify(capture, null, 2);

            const fileBody =
                'const capture = ' + payload + ';\n' +
                'const revive = (x) => { if (x === null || x === undefined) return x; if (Array.isArray(x)) return x.map(revive); if (typeof x === "object") { if (typeof x.__b64__ === "string") return Buffer.from(x.__b64__, "base64"); if (typeof x.b64 === "string") return Buffer.from(x.b64, "base64"); return Object.fromEntries(Object.entries(x).map(([k, v]) => [k, revive(v)])); } return x; };\n' +
                'await client.relayMessage(m.chat, revive(capture.message), {});\n';

            const introText = fmt(`Compiled snip dn (${fileBody.length} chars)\nSvv.\nUse Done✅`);

            await sendRichCode(client, m, introText, fileBody, 'javascript');
            await client.sendMessage(m.chat, { react: { text: '✅', key: m.reactKey } });
        } catch (e) {
            await client.sendMessage(m.chat, { react: { text: '❌', key: m.reactKey } }).catch(() => {});
            await sendInteractive(client, m, fmt('Failed to compile: ' + (e?.message || e)));
        }
    });
};
