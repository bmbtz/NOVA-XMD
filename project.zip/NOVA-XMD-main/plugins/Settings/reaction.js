import { generateWAMessageFromContent } from '@whiskeysockets/baileys';
import { getSettings, updateSetting } from '../../database/config.js';
import ownerMiddleware from '../../utils/botUtil/Ownermiddleware.js';
import { getDeviceMode } from '../../lib/deviceMode.js';
import { sendInteractive } from '../../lib/sendInteractive.js';

export default async (context) => {
  await ownerMiddleware(context, async () => {
    const { client, m, args, prefix } = context;
        await client.sendMessage(m.chat, { react: { text: '⌛', key: m.reactKey } });

    const fmtMsg = (msg) => `│ ${msg}\n╰───────────────\n> ©BMB TECH`;

    try {
      const settings = await getSettings();
      const newEmoji = args[0];
      const currentEmoji = settings.autolikeemoji || 'random';

      if (newEmoji) {
        if (newEmoji === 'random') {
          if (currentEmoji === 'random') {
            await client.sendMessage(m.chat, { react: { text: '❌', key: m.reactKey } });
            await client.sendMessage(m.chat, { react: { text: '❌', key: m.reactKey } }).catch(() => {});
            return await client.sendMessage(m.chat, { text: fmtMsg('Already using random emojis, you brain-dead fool!') });
          }
          await updateSetting('autolikeemoji', 'random');
          await client.sendMessage(m.chat, { react: { text: '✅', key: m.reactKey } });
          return await client.sendMessage(m.chat, { text: fmtMsg('Reaction emoji set to random! Happy now?') });
        } else {
          if (currentEmoji === newEmoji) {
            await client.sendMessage(m.chat, { react: { text: '❌', key: m.reactKey } }).catch(() => {});
            return await client.sendMessage(m.chat, { text: fmtMsg(`Already using ${newEmoji} emoji, moron!`) });
          }
          await updateSetting('autolikeemoji', newEmoji);
          await client.sendMessage(m.chat, { react: { text: '✅', key: m.reactKey } });
          return await client.sendMessage(m.chat, { text: fmtMsg(`Reaction emoji set to ${newEmoji}!`) });
        }
      }

      const currentText = currentEmoji === 'random' ? 'Random emojis' : `${currentEmoji} emoji`;

          await client.sendMessage(m.chat, { react: { text: '📋', key: m.reactKey } });
          await sendInteractive(client, m, `📌 *REACTION*\n━━━━━━━━━━━━━━━━\nStatus: ${settings.reaction ? 'ON ✅' : 'OFF ❌'}\nOptions:\n${prefix}reaction random\n${prefix}reaction ❤️\n${prefix}reaction 🔥\n${prefix}reaction 😂\n━━━━━━━━━━━━━━━━\n© bmb tech`);

    } catch (error) {
    await client.sendMessage(m.chat, { react: { text: '❌', key: m.reactKey } }).catch(() => {});
      console.error('Reaction command error:', error);
      await client.sendMessage(m.chat, { text: fmtMsg("Failed to update reaction settings. Something's broken.") });
    }
  });
};
